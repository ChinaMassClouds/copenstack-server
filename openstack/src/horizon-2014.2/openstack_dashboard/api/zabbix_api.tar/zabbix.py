#!/usr/bin/env python

import json
import urllib2
import sys
import time
import datetime
import ConfigParser


def time_str(date):
    localdate = time.localtime(date)
    return time.strftime('%Y-%m-%dT%H:%M:%S',localdate)

def yesterday():
    today=datetime.datetime.now()
    oneday=datetime.timedelta(days=1) 
    today=today-oneday
    return time.mktime(today.timetuple())


def keys(path):
    conf = ConfigParser.ConfigParser()
    conf.read(path)
    return conf

class zabbixtools:

    def __init__(self, url, user, password, path):
        self.url = url
        self.user = user
        self.password = password
        self.header = {"Content-Type": "application/json"}
        self.authID = self.user_login()
        self.keys = keys(path)

    def user_login(self):
        data = json.dumps(
                {
                    "jsonrpc": "2.0",
                    "method": "user.login",
                    "params": {
                        "user": self.user,
                        "password": self.password 
                        },
                    "id": 0
                    })
        request = urllib2.Request(self.url,data)
        for key in self.header:
            request.add_header(key,self.header[key])
        try:
            result = urllib2.urlopen(request)
        except URLError as e:
            print "Auth Failed, Please Check Your Name And Password:",e.code
        else:
            response = json.loads(result.read())
            result.close()
            authID = response['result']
            return authID

    def get_data(self,data,hostip=""):
        request = urllib2.Request(self.url,data)
        for key in self.header:
            request.add_header(key,self.header[key])
        try:
            result = urllib2.urlopen(request)
        except URLError as e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server could not fulfill the request.'
                print 'Error code: ', e.code
            return 0
        else:
            response = json.loads(result.read())
            result.close()
            return response

    def host_get(self, hostname):
        data = json.dumps({
                    "jsonrpc": "2.0",
                    "method": "host.get",
                    "params": {
                        "output":['hostid',"status"],
			"filter": {"name":hostname}
			},
                    "auth": self.authID,
                    "id": 1
                })
        res = self.get_data(data)['result']
        if not res:
            return False
        else:
            return res[0]['hostid']
    
    def item_get(self, hostid, key):
        data = json.dumps({
                    "jsonrpc": "2.0",
                    "method": "item.get",
                    "params": {
             		"output": "extend",
         	        "hostids": hostid,
   	                "search": {
	  			"key_": key
			},
                    "sortfield": "name"
                    },
 	            "auth": self.authID,
		    "id": 1})
        res = self.get_data(data)['result']
        if res: 
             return res[0]['itemid']
        else:
             return False


    def item_create(self, hostid, key):
        data =json.dumps({
                    "jsonrpc": "2.0",
                    "method": "item.create",
                    "params": {
         	        "hostids": hostid,
                        "name" : "test item create",
			"search":{
	  		"key_":key
			},
                    "sortfield": "name"
                    },
 	            "auth": self.authID,
		    "id": 1	
		})
        res = self.get_data(data)['result']
        if not res:
            return False
        else:
            return res[0]['itemid']


    def hostgroup_get(self, name): 
	data = json.dumps({
  		  "jsonrpc": "2.0",
  		  "method": "hostgroup.get",
  		  "params": {
  		      "selectHosts":'name',
  		      "output": "extend",
  		      "filter": {
  		          "name": name}
  		                },
  		  "auth":self.authID,
  		  "id": 1
                })
        res = self.get_data(data)['result']
        if not res:
            return False
        else:
            return res[0]['hosts'] 


    def trigger_create(self ,name, trigger_exp,leven):
        data = json.dumps({
		    "jsonrpc": "2.0",
		    "method": "trigger.create",
		    "params": {
		        "description": name,
		        "expression": trigger_exp,
		        "priority": str(leven)
		    },
		    "auth": self.authID,
		    "id": 1})
        res = self.get_data(data)["result"]
        if not res:
            return False
        else:
            return res


    def trigger_id(self, name):
	data = json.dumps({
		    "jsonrpc": "2.0",
		    "method": "trigger.get",
		    "params": {
		     "output": "extend",
		     "selectHosts":"extend",
		     "filter":{ "description":name}
		      },
		    "auth": self.authID,
		    "id": 1
		     })
        res = self.get_data(data)['result']
        if not res:
            return False
        else:
            return res[0]['triggerid']

    def trigger_delete(self, name):
        trigger_id = self.trigger_id(name)
    	data = json.dumps({
		    "jsonrpc": "2.0",
		    "method": "trigger.delete",
		    "params": 
		         [trigger_id]
		    ,
		    "auth": self.authID,
		    "id": 1
        })
        res = self.get_data(data)['result']
        if not res:
            return False
        else:
            return res


    def trigger_get(self, host=''):
	data = json.dumps({
		    "jsonrpc": "2.0",
		    "method": "trigger.get",
		    "params": {
		     "output": "extend",
		     "selectHosts":"extend",
       		},
		    "auth": self.authID,
		    "id": 1
		     })
        res = self.get_data(data)['result']
        if not res:
	    return False
        else:
            return res
        
    def trigger_enabled(self, name):
        trigger_id = self.trigger_id(name)
	data = json.dumps({
		    "jsonrpc": "2.0",
		    "method": "trigger.update",
		    "params": {
		        "triggerid": trigger_id,
		        "status": 0
		    },
		    "auth": self.authID,
		    "id": 1
		})
        res = self.get_data(data)['result']
        if not res:
             return False 
        else:
             return res 

    def trigger_disabled(self, name):
        trigger_id = self.trigger_id(name)
	data = json.dumps({
		    "jsonrpc": "2.0",
		    "method": "trigger.update",
		    "params": {
		        "triggerid": trigger_id,
		        "status": 1
		    },
		    "auth": self.authID,
		    "id": 1
		})
        res = self.get_data(data)['result']
        if not res:
             return False 
        else:
             return res 

    def _data_get(self, hostid, key, history = True):
        itemid = self.item_get(hostid, key)
        value = '3'
        data = json.dumps({
                        "jsonrpc": "2.0",
                        "method": "history.get",
                        "params": {
                            "output": "extend",
                            "history": value,
                            "itemids": itemid,
                            "sortfield": "clock",
                            "sortorder": "ASC",
	              	    "time_from": str(yesterday()),
                            "time_till": str(time.time())
                        },
                        "auth": self.authID,
                        "id": 1
                    })
        res = self.get_data(data)['result']
        if not res:
             return False 
        _data = [] 
        for re in res:
            _data.append([time_str(int(re['clock'])),re['value']])
        return json.dumps(_data)

    def cpu(self, hostname):
        hostid = self.host_get(hostname)
        key = self.vm_host_rel(hostid, "cpu")
        cpu = self._data_get(hostid, key)
        return cpu

    def memory(self, hostname):
        hostid = self.host_get(hostname)
        key = self.vm_host_rel(hostid, "memory")
        memory = self._data_get(hostid, key)
        return memory 

    def net(self, hostname):
        hostid = self.host_get(hostname)
        keys = self.vm_host_rel(hostid, ("net_in","net_out"))
        net_in = self._data_get(hostid, keys[0])
        net_out = self._data_get(hostid, keys[1])
        return net_in,net_out

    def io(self, hostname):
        hostid = self.host_get(hostname)
        keys = self.vm_host_rel(hostid, ("io_in","io_out"))
        io_in = self._data_get(hostid, keys[0])
        io_out = self._data_get(hostid, keys[1])
        return io_in,io_out 

    def create(self, name ,hostname, key, val, level, time=0,avg=False): 
        hostid = self.host_get(hostname)
        keys = self.vm_host_rel(hostid, key)
        if avg:
            trigger_exp = "{"+hostname+":"+keys+".avg("+time+")}>"+str(val)
        else:
            trigger_exp = "{"+hostname+":"+keys+".last()}>"+str(val)
        return self.trigger_create(name, trigger_exp, level)
            

    def delete(self, name):
	return self.trigger_delete(name)

    def find(self):
        return self.trigger_get()

    def enabled(self, name):
        return self.trigger_enabled(name)

    def disabled(self, name):
        return self.trigger_disabled(name)

    def vm_host_rel(self, hostid, key):
        hostids = test.hostgroup_get('cluster (vm)')
        if hostid in [host['hostid'] for host in hostids]:
           if isinstance(key,tuple):          
	       return (self.keys.get("vm",key[0]),self.keys.get("vm",key[1]))
	   else:
	       return self.keys.get("vm",key) 
        else:
           if isinstance(key,tuple):
	       return (self.keys.get("host",key[0]),self.keys.get("host",key[0]))
	   else:
	       return self.keys.get("host",key) 
		        

if __name__ == "__main__":
    url = "http://192.168.15.132/zabbix/api_jsonrpc.php"
    #url = "http://192.168.15.98/zabbix/api_jsonrpc.php"
    user = "admin"
    password = "zabbix"
    test = zabbixtools(url, user, password, "key.ini")
    #print test.find()   
    #print test.create("zc","Zabbix Server","cpu",80,3,"5m",True)     
    #print test.enabled("zc")
    #print test.disabled("zc")
    #print  test.delete("zc")

    #arg1=get arg2=hostname arg3=type ps:io_in io_out net_in net_out
    #arg4=trigger_val arg5=log level arg6=time arg7=avg open
    #print test.create("zc","Zabbix Server","cpu",80,3,"5m",True)     
    #print test.cpu("Zabbix Server")
    #print test.io("Zabbix Server")
    #print test.memory("Zabbix Server")
    #print test.net("Zabbix Server")
